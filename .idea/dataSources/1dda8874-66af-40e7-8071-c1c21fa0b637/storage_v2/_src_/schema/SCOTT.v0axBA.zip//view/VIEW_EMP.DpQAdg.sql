CREATE VIEW VIEW_EMP AS
  SELECT empno || ' ' || ename AS str FROM emp
/

